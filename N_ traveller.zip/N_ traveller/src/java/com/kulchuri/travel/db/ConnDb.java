/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.travel.db;

import java.sql.*;

/**
 *
 * @author hp
 */
public class ConnDb {
    private static final String PWD="root";
    private static final String USER="root";
    private static final String URL="jdbc:mysql://localhost:3306/ntravel";
    private static final  String Driver="com.mysql.jdbc.Driver";
    private  static Connection conn=null;
    
    static{
        try {
            Class.forName(Driver);
            conn=DriverManager.getConnection(URL, USER, PWD);
            
        } catch (Exception e) {
            System.out.println("Exception at Crudbd(): "+e);
        }
    }
    public static Connection getCruddb(){
    return conn;
    }
    
    public static void main(String[] args) {
        System.out.println(getCruddb());
    }
}
