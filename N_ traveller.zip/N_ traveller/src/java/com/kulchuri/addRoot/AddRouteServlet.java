/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.addRoot;

import com.kulchuri.Utility.KFMSDate;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
@WebServlet(urlPatterns = {"/addRoute"})
public class AddRouteServlet  extends HttpServlet{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doPost(req, resp); //To change body of generated methods, choose Tools | Templates.
    String name=req.getParameter("name");
    String busno=req.getParameter("busno");
//    int b=Integer.parseInt(busno);
    String date=KFMSDate.getCurrentDate(); 
    
AddRouteDto dto=new AddRouteDto();
dto.setName(name);
dto.setBusno(busno);
dto.setDate(date);
 AddRouteDao dao = new AddRouteDao();
        if (dao.addRoute(dto)) {
            resp.sendRedirect("viewAllRoute.jsp");
        } else {
            resp.sendRedirect("signin.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doGet(req, resp); //To change body of generated methods, choose Tools | Templates.
    String rno=req.getParameter("rid");
    int rid=Integer.parseInt(rno);
    AddRouteDao dao= new AddRouteDao();
    dao.deleteRoute(rid);
    resp.sendRedirect("viewAllRoute.jsp");
    }
    
    }
    
    

