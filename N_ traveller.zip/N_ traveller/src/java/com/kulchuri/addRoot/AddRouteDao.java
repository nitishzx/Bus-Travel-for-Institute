/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.addRoot;

import com.kulchuri.DriverAdd.DriverDto;
import com.kulchuri.travel.db.ConnDb;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class AddRouteDao {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public AddRouteDao() {
    }

    public boolean addRoute(AddRouteDto dto) {
        boolean flag = false;
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "insert into route(name, busno, date) values(?,?,?)";
            ps = conn.prepareCall(sql);
            ps.setString(1, dto.getName());
            ps.setString(2, dto.getBusno());
            ps.setString(3, dto.getDate());

            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at AddRouteDao(): " + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }

    public ArrayList<AddRouteDto> getAllRoute() {
        ArrayList<AddRouteDto> al = new ArrayList<>();
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "select * from route";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            AddRouteDto dto;
            while (rs.next()) {
                dto = new AddRouteDto();
                dto.setRid(rs.getInt("rid"));
                dto.setName(rs.getString("name"));
                dto.setBusno(rs.getString("busno"));
                dto.setDate(rs.getString("date"));
                al.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at getAllRouteDao(): " + e);
        } finally {
            rs = null;
            conn = null;
            ps = null;
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
        
    }
     public void deleteRoute(int rid) {
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {

            String sql="delete from route where rid=?";
               ps = conn.prepareStatement(sql);
            ps.setInt(1, rid);
            ps.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at deleteRoute(): "+e);
        }finally{
        rs=null;
        ps=null;
        conn=null;
        
        
        }
     }
    public AddRouteDto getRoute(int rid) {

        AddRouteDto dto = null;

        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "select * from route where rid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, rid);
            rs = ps.executeQuery();
            if (rs.next()) {
                dto = new AddRouteDto();
                
                 dto.setRid(rs.getInt("rid"));
                dto.setName(rs.getString("name"));
                dto.setBusno(rs.getString("busno"));
                dto.setDate(rs.getString("date"));
               

            }
        } catch (Exception e) {
            System.out.println("Exception caught at getRoute method : " + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return dto;
        }
    }
    
    public boolean updateRoute(AddRouteDto dto) {
        boolean flag = false;
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "update route set name=?,busno=? where rid=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, dto.getName());
            ps.setString(2, dto.getBusno());
          ps.setInt(3,dto.getRid());

            if (ps.executeUpdate() > 0) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Excepton at updateRoute():" + e);
        } finally {
            ps = null;
            conn = null;
            return flag;
        }
    }
    
}
