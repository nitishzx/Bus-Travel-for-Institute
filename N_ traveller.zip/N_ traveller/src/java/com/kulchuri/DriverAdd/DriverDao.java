/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.DriverAdd;

import com.kulchuri.travel.db.ConnDb;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Base64;

/**
 *
 * @author hp
 */
public class DriverDao {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public DriverDao() {
    }

    public boolean addDriver(DriverDto dto, InputStream photo) {
        boolean flag = false;
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {

            String sql = "insert into driver(name, bid, email, mno, address, photo) values(?,?,?,?,?,?)";
            ps = conn.prepareCall(sql);
            ps.setString(1, dto.getName());
            ps.setInt(2, dto.getBid());
            ps.setString(3, dto.getEmail());
            ps.setString(4, dto.getMno());
            ps.setString(5, dto.getAddress());

            ps.setBlob(6, photo);

            if (ps.executeUpdate() > 0) {
//                System.out.println("Sucess");
                flag = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at addTraveller: " + e);
        } finally {
            ps = null;
            rs = null;
            conn = null;
            return flag;
        }

    }

    public ArrayList<DriverDto> getAllDriver() {
        ArrayList<DriverDto> al = new ArrayList<>();

        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "select * from driver";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                DriverDto dto = new DriverDto();
                dto.setDid(rs.getInt("did"));

                dto.setName(rs.getString("name"));
                dto.setBid(rs.getInt("bid"));
                dto.setMno(rs.getString("mno"));
                dto.setAddress(rs.getString("address"));

                Base64.Encoder encoder = Base64.getEncoder();
                String photo = encoder.encodeToString(rs.getBytes("photo"));
                dto.setPhoto(photo);
                al.add(dto);

            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at getAllDriver(): " + e);
        } finally {
            ps = null;
            conn = null;
            return al;
        }

    }

    public ArrayList<DriverDto> viewAllDriver() {
        ArrayList<DriverDto> al = new ArrayList<>();
//    boolean flag=false;
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "select * from driver";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                DriverDto dto = new DriverDto();
                dto.setDid(rs.getInt("did"));
                dto.setName(rs.getString("name"));
                dto.setBid(rs.getInt("bid"));
                dto.setEmail(rs.getString("email"));
                dto.setMno(rs.getString("mno"));
                dto.setAddress(rs.getString("address"));

                Base64.Encoder encoder = Base64.getEncoder();
                String photo = encoder.encodeToString(rs.getBytes("photo"));
                dto.setPhoto(photo);

                al.add(dto);

            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at viewAllDriver(): " + e);
        } finally {
            conn = null;
            return al;

        }

    }

    public boolean updateDriver(DriverDto dto) {
        boolean flag = false;
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "update driver set name=?, bid=?, email=?, mno=?, address=? where did=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, dto.getName());
            ps.setInt(2, dto.getBid());
            ps.setString(3, dto.getEmail());
            ps.setString(4, dto.getMno());
            ps.setString(5, dto.getAddress());
            ps.setInt(6, dto.getDid());
            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at updateDriver(): " + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }

    public void deleteDriver(int tid) {
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {

            String sql = "delete from driver where did=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, tid);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Exception at deleteDriver(): " + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;

        }

    }

    public DriverDto getDriver(int did) {

        DriverDto dto = null;

        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {
            String sql = "select * from driver where did=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, did);
            rs = ps.executeQuery();
            if (rs.next()) {
                dto = new DriverDto();
                dto.setDid(rs.getInt("did"));
                dto.setName(rs.getString("name"));
                dto.setBid(rs.getInt("bid"));
                dto.setEmail(rs.getString("email"));
                dto.setMno(rs.getString("mno"));
                dto.setAddress(rs.getString("address"));

            }
        } catch (Exception e) {
            System.out.println("Exception caught at update method : " + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return dto;
        }
    }
}
