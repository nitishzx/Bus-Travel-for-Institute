/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.DriverAdd;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hp
 */
@WebServlet(urlPatterns = {"/update"})
public class UpdateDriverServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doPost(req, resp); //To change body of generated methods, choose Tools | Templates.

        String name = req.getParameter("name");
        String did=req.getParameter("did");
        String bid = req.getParameter("bid");
//      int bid=Integer.parseInt("bno");
        String email = req.getParameter("email");
        String mno = req.getParameter("mno");
        String address = req.getParameter("address");

        DriverDto dto = new DriverDto();
        dto.setDid(Integer.parseInt(did));
        dto.setName(name);
        dto.setEmail(email);
        dto.setMno(mno);
        dto.setAddress(address);
        int bno = Integer.parseInt(bid);
        dto.setBid(bno);

        DriverDao dao = new DriverDao();
        if (dao.updateDriver(dto)) {
            resp.sendRedirect("viewAllDriver.jsp");
        } else {
            resp.sendRedirect("updateDriver.jsp?did=" + did);
        }

        
        
    }
    
}
