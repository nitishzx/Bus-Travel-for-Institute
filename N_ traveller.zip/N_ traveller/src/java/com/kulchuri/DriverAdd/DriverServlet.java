package com.kulchuri.DriverAdd;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.*;

@WebServlet(urlPatterns = {"/addDriver"})
@MultipartConfig(maxFileSize = 98989999)
public class DriverServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doPost(req, resp); //To change body of generated methods, choose Tools | Templates.

        PrintWriter pw = resp.getWriter();
//        pw.print("hello ");
        try {
            String name = req.getParameter("name");
            String bid = req.getParameter("bid");
            int b = Integer.parseInt(bid);
            String email = req.getParameter("email");
            String mno = req.getParameter("mno");
            String add = req.getParameter("address");

            Part part = req.getPart("photo");
            InputStream photo = part.getInputStream();

            DriverDto dto = new DriverDto();
            dto.setName(name);
            dto.setBid(b);
            dto.setEmail(email);
            dto.setMno(mno);
            dto.setAddress(add);

            DriverDao dao = new DriverDao();
            boolean f = dao.addDriver(dto, photo);

            if (f) {
                resp.sendRedirect("viewAllDriver.jsp");
            } else {
                pw.print("failed");
            }

        } catch (Exception e) {
            e.printStackTrace(); 
            System.out.println("Failed TravellerServet(): ");
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doGet(req, resp); //To change body of generated methods, choose Tools | Templates.
    String tno=req.getParameter("tno");
    int tid=Integer.parseInt(tno);
    DriverDao dao=new DriverDao();
    dao.deleteDriver(tid);
    resp.sendRedirect("viewAllDriver.jsp");
    
    }
   
}
