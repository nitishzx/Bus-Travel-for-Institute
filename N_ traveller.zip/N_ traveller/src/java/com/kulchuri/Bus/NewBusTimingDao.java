/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.Bus;

import com.kulchuri.travel.db.ConnDb;
import java.sql.Connection;
import java.sql.*;

/**
 *
 * @author hp
 */
public class NewBusTimingDao {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public NewBusTimingDao() {
    }

    public boolean addBus(NewBusTimingDto dto) {
        boolean flag = false;
        if (conn == null) {
            conn = ConnDb.getCruddb();
        }
        try {

            String sql = "insert into (sid, timing, date) values(?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, dto.getSid());
            ps.setString(2,dto.getTiming());
            ps.setString(3, dto.getDate());
            
            if(ps.executeUpdate()>0){
            flag=true;
            }
        } catch (Exception e) {
            System.out.println("Exception at addBus(): " + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }
    
}
